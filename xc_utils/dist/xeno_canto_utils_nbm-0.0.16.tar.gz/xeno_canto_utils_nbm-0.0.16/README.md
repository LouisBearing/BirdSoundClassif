# BirdSoundClassif

How to install the package:

`pip install xeno-canto-utils-nbm`

How to use it:

`xeno -s "pluvialis squatarola" -t "nocturnal flight call" -lt 30 -q D -o output_folder`
